<?php
require_once './include/conn.php';

header('Content-Type: application/json; charset=utf-8');

if (isset($_GET['type'])) {
    $type = $conn->real_escape_string($_GET['type']);
    
    $sql = "SELECT message, delay FROM h_system_messages WHERE type = ? ORDER BY id DESC LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $type);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        echo json_encode([
            'status' => 'success',
            'message' => $row['message'],
            'delay' => $row['delay']
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => '未找到对应的系统消息'
        ]);
    }
    
    $stmt->close();
} else {
    echo json_encode([
        'status' => 'error',
        'message' => '缺少必要参数'
    ]);
}

$conn->close();
?> 