<?php
require_once './include/conn.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = isset($_POST['message']) ? $conn->real_escape_string($_POST['message']) : '';
    $type = isset($_POST['type']) ? $conn->real_escape_string($_POST['type']) : 'normal';
    $delay = isset($_POST['delay']) ? intval($_POST['delay']) : 0;
    
    if (empty($message)) {
        echo json_encode([
            'status' => 'error',
            'message' => '消息内容不能为空'
        ]);
        exit;
    }
    
    $sql = "INSERT INTO h_system_messages (message, type, delay) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $message, $type, $delay);
    
    if ($stmt->execute()) {
        echo json_encode([
            'status' => 'success',
            'message' => '系统消息保存成功'
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => '保存失败: ' . $stmt->error
        ]);
    }
    
    $stmt->close();
} else {
    echo json_encode([
        'status' => 'error',
        'message' => '请求方法不正确'
    ]);
}

$conn->close();
?> 